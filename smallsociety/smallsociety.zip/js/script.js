for(var i=2; i<5;i++){
	$('#section' + i).hide();
}
var cnt=1;
setTimeout(function(){
	$(window).on('wheel', function(e){
		var delta = e.originalEvent.deltaY;
		if(delta >0 && cnt < 4){
			$('#section' + cnt).hide();
			cnt++;
			$('#section' + cnt).fadeIn(2000);
		}else if(delta <=0 && cnt >1){
			$('#section' + cnt).hide();
			cnt--;
			$('#section' + cnt).fadeIn(2000);
		}
	});
},4000);




